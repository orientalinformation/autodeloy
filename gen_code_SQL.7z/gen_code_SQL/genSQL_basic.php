<?php
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>> SETTING >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/* INPUT */
// nội dung DD
$pathFileDD = './Detail_design.txt';
// cấu trúc DD
$arrTypeMain = array(
'【更新】' => 'update', 
'【取得】' => 'get', 
'【削除】' => 'delete', 
'【登録】' => 'regist');
$arrTypePartOfMain = array(
'/^(対象テーブル)/' => 'alias', 
'/^(更新条件|検索条件)\s?\d?/' => 'condition', 
'/^(取得項目)/' => 'field_get', 
'/^(取得順|ソート順|ソート条件)/' => 'order', 
'/^(更新項目)/' => 'field_update', 
'/^(登録項目)/' => 'field_insert', 
'/^(結合条件)/' => 'join', 
'/^(グループ条件)/' => 'group');
$arrKeyMainSkip = array(
'',
'30	【削除】セッション（フロント）',
'31	【削除】セッション（管理）'
);

/* OUTPUT */
$formatGenPHP = '
// <keymain> DB_<type>_<no>
<SQL>';
$pathFileOutput = 'genSQL.txt';
//<<<<<<<<<<<<<<<<<<<<<<<<<<<< SETTING <<<<<<<<<<<<<<<<<<<<<<<<<<<<

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>> FUNCTION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
function isContent($regex, $eContent) {
    preg_match_all($regex, $eContent, $foo);
    if (count($foo[0]) > 0) {
        return true;
    }
    return false;
}
function showError($result) {
    echo "\nERROR>>>>>>>>>>>>";
    var_export($result);
    echo "\nERROR<<<<<<<<<<<<<";
    exit;
}
function wrapcode($str) {
    return wordwrap($str, 120, __break_sub__);
}
function genSQL($type, $data) {
    $SQL = "";
    if ($type == 'alias') {
        if (isset($data['join'])) {
            $SQL = " " . implode(" ", $data['join']) . " ";
            foreach ($data['alias'] as $kAlias => $vAlias) {
                $SQL = str_replace(" " . $kAlias . " ", " " . $vAlias . " " . $kAlias . " ", $SQL);
            }
        } else {
            foreach ($data[$type] as $kAlias => $vAlias) {
                if ($kAlias == $vAlias) {
                    $SQL = $vAlias;
                } else {
                    $SQL = $vAlias . " " . $kAlias;
                }
                break;
            }
        }
    }
    if ($type == 'condition') {
        $breakAlign16 = "";
        $arrTemp = array();
        foreach ($data[$type] as $eCondition) {
            $eCondition = ($eCondition);
            $arrTemp[] = $breakAlign16.$eCondition;
            $breakAlign16 = str_repeat(" ", 16);
        }
        $SQL = implode("\n", $arrTemp);
        $SQL = str_replace(". ", ".", $SQL);
    }
    if ($type == 'field_update' || $type == 'field_insert') {
        $arrFieldUpdate = array();
        foreach ($data[$type] as $field => $value) {
            $arrFieldUpdate[] = $field. " = $value";
            $SQL = implode(", \n", $arrFieldUpdate);
        }
    }
    if ($type == 'field_get') {
        $SQL = implode(", ", $data[$type]);
        $SQL = str_replace(" ,", ",", $SQL);
        return $SQL;
    }
    if ($type == 'order' || $type == 'group') {
        $SQL = implode(", ", $data[$type]);
        $SQL = str_replace(array('GROUP BY', 'ORDER BY'), "", $SQL);
        return $SQL;
    }
    return $SQL;
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<< FUNCTION <<<<<<<<<<<<<<<<<<<<<<<<<<<<
$kv_texts = file_get_contents($pathFileDD);
if($kv_texts === false) {
    echo 'Cant Read that file.';die;
}
echo "\n$pathFileDD\n";

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>> INIT >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
$arrContent = explode("\r\n", $kv_texts);
$arrCollect = array();
$keyMain = "";
$keySub = "";
$no = 1;
$flagAreaSQL = true;
$keyAction = "SQL";
define('__break_sub__', "\n".str_repeat(" ", 16));
//<<<<<<<<<<<<<<<<<<<<<<<<<<<< INIT <<<<<<<<<<<<<<<<<<<<<<<<<<<<
$strListKeyMain = implode('|', array_keys($arrTypeMain));
foreach ($arrContent as $key => $eContent) {
    if (isContent("/^.*(".$strListKeyMain.").*/", $eContent) || isContent("/^(No\.00\d\d).*/", $eContent)) {
        $keyMain = $keyAction.$eContent;
        $keySub = '';
        if (!isset($arrCollect[$keyMain]) && !in_array($keyMain, $arrKeyMainSkip)) {
            preg_match_all("/^.*(".$strListKeyMain.").*/", $eContent, $result);
            $arrCollect[$keyMain] = array('no' => $no);
            if (isset($result[1][0]) && isset($arrTypeMain[$result[1][0]])) {
                $arrCollect[$keyMain]['type'] = $arrTypeMain[$result[1][0]];
            } else {
                $arrCollect[$keyMain]['type'] = 'other';
            }
            
        }
        $no++;
        continue;
    }
    //if ($keyMain != '2.1.1.5.2    「検索」ボタンクリックNo.0001 【取得】お客さま件数取得') continue;
    if (in_array($keyMain, $arrKeyMainSkip)) {
        $arrCollect[$keyMain]['type'] = 'skip';
        continue;
    }
    $flagContinue = false;
    foreach ($arrTypePartOfMain as $keyPOM => $valuePOM) {
        if (isContent($keyPOM, $eContent)) {
            $keySub = $valuePOM;
            $flagContinue = true;
            break;
        }
    }
    if ($flagContinue == true) {
        continue;
    }

    if ($keySub == 'field_update' || $keySub == 'field_insert') {
        preg_match_all("/\d\t[^\t]+\t([^\t]+)\t([^\t]+)/", $eContent, $result);
        // Skip
        if (count($result[1]) == 0) {
            continue;
        }
        // OK
        $arrCollect[$keyMain][$keySub][$result[1][0]] = $result[2][0];
    }
    elseif ($keySub == 'field_get') {
        preg_match_all("/\d\t[^\t]+\t([^\t]+)\t.*/", $eContent, $result);
        // Skip
        if (count($result[1]) == 0) {
            continue;
        }
        // OK
        $arrCollect[$keyMain][$keySub][$result[1][0]] = $result[1][0];
    }
    elseif ($keySub == 'alias') {
        preg_match_all("/.*\s([\w]+\s+[\w]+)\s?$/", $eContent, $result);
        var_dump($keyMain);var_dump($eContent);
        // Skip
        if (count($result[1]) == 0) {
            preg_match_all("/.*\(\s([\w]+\s+[\w]+)\s\)$/", $eContent, $result);
        }
		
        if (count($result[1]) == 0) {
            preg_match_all("/.*\s([\w]+)$/", $eContent, $result);
        }
        if (count($result[1]) == 0) {
            continue;
        }
        // OK
        $result[1][0] = str_replace('  ', ' ', $result[1][0]);
        $temp = explode(' ', $result[1][0]);
        if (count($temp) == 1) {
            $arrCollect[$keyMain][$keySub][$temp[0]] = $temp[0];
        }
        if (count($temp) == 2) {
			
            $arrCollect[$keyMain][$keySub][$temp[1]] = $temp[0];
        }
    }
    else {
        if ($eContent != '') $arrCollect[$keyMain][$keySub][] = $eContent;
    }
}
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>> GEN >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
$result = array();
foreach ($arrCollect as $keyMain => $eCollect) {
    $partSQL = array();
    foreach ($arrTypePartOfMain as $eKeyPart) {
        if (isset($eCollect[$eKeyPart])) {
            $partSQL[$eKeyPart] = genSQL($eKeyPart, $eCollect);
            if ($eKeyPart != 'condition') {
                $partSQL[$eKeyPart] = str_replace(array("\n", "\t", "  "), " ", $partSQL[$eKeyPart]);
                if ($eKeyPart == 'field_get' || $eKeyPart == 'field_update') {
                    $partSQL[$eKeyPart] = str_replace(", ", ",".__break_sub__, $partSQL[$eKeyPart]);
                } else {
                    $partSQL[$eKeyPart] = wrapcode($partSQL[$eKeyPart]);
                }
            }
        }
    }
    $breakAlign = "\n".str_repeat(" ", 4);
    
    $SQL = "";
    if (isset($partSQL['field_get'])) {
        $partSQL['field_get'] = ($partSQL['field_get']);
        $SQL = "SELECT {$partSQL['field_get']} {$breakAlign}FROM {$partSQL['alias']} {$breakAlign}WHERE {$partSQL['condition']} ";
        if (isset($partSQL['order'])) {
            $SQL .= "{$breakAlign}ORDER BY {$partSQL['order']}";
        }
        if (isset($partSQL['group'])) {
            $SQL .= "{$breakAlign}GROUP BY {$partSQL['group']}";
        }
        if (!isset($partSQL['alias'])) {
            var_dump($keyMain);var_dump($eCollect);
        }
        
    } elseif (isset($partSQL['field_update'])) {
        $partSQL['field_update'] = ($partSQL['field_update']);
        $SQL = "UPDATE {$partSQL['alias']} {$breakAlign}SET {$partSQL['field_update']} {$breakAlign}WHERE {$partSQL['condition']} ";
    } elseif (isset($partSQL['field_insert'])) {
        $partSQL['field_insert'] = ($partSQL['field_insert']);
        $SQL = "INSERT INTO {$partSQL['alias']} "
        .("(".implode(', ',array_keys($eCollect['field_insert'])).")")
        ."{$breakAlign}VALUES "
        ."(".implode(', ',array_values($eCollect['field_insert'])).");";
    } else {
        if (isset($partSQL['alias']) && isset($partSQL['condition'])) {
            $SQL = "DELETE FROM {$partSQL['alias']} {$breakAlign}WHERE {$partSQL['condition']}";
        } else {
            //var_dump($keyMain);var_dump($eCollect);
        }
    }
    
    if ($SQL != '') {
        $codeGenBindArray = array();
        $codeGen = $formatGenPHP;
        $codeGen = str_replace('<keymain>', $keyMain, $codeGen);
        $codeGen = str_replace('<type>', $eCollect['type'], $codeGen);
        $codeGen = str_replace('<SQL>', $SQL, $codeGen);
        $codeGen = str_replace('<no>', $eCollect['no'], $codeGen);
        $result[] = "";
        $result[] = $codeGen;
    }
}

file_put_contents($pathFileOutput, implode(PHP_EOL, $result));
//<<<<<<<<<<<<<<<<<<<<<<<<<<<< GEN <<<<<<<<<<<<<<<<<<<<<<<<<<<<
