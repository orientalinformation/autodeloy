#!/bin/bash

MG_MIGRATION_FLAG="1" 
VHOST_PATH="/etc/httpd/vhosts/"
APACHE_LOG_PATH="/var/log/httpd/"
VHOST_TEMP_FILE="vhost.conf.tmpl"

help() {
    echo "Usage: [this file] [HINMOKU] [SVN URL]"
    echo "E.g: ./deploy_hinmoku.sh c0037777 SVN"
}

check() {
    ERRORS=()
    if [ ! -f ${VHOST_PATH}${VHOST_TEMP_FILE} ]
    then
        MESSAGE="The vhost template file [${VHOST_TEMP_FILE}] does not exist. You can upload [${VHOST_TEMP_FILE}] file from [Deploy_Old_Env] folder to ${VHOST_PATH}"
        ERRORS+=("${MESSAGE}")
    fi

    if [ ${#ERRORS[@]} -ne 0 ]
    then
        echo "============================ CHECK FAILED ============================"
        INDEX=1
        for value in "${ERRORS[@]}"
        do
            echo -e "*\t${INDEX}. ${value}"
            INDEX+=1
        done
        echo "======================================================================"
        
        return 0
    fi
    
    return 1
}

getIpAddress() {
    IP_LIST=$(hostname -I)
    IP_ARRAY=($IP_LIST)
    IP="Empty"
    if [ ${#IP_ARRAY[@]} -ne 0 ]
    then
        IP=${IP_ARRAY[0]}
    fi

    echo $IP
}

createDatabase() {
    echo "Enter password for mysql root user"
    mysql -uroot -p -e "CREATE USER '${HINMOKU}'@'localhost' IDENTIFIED BY '${HINMOKU}p';
    GRANT ALL PRIVILEGES ON * . * TO '${HINMOKU}'@'localhost';"
    mysql -u${HINMOKU} -p${HINMOKU}p -e "DROP DATABASE IF EXISTS ${HINMOKU};
    CREATE DATABASE ${HINMOKU};"
}

createMail() {
    MAIL_LIST=(
        default_${HINMOKU}@webmail.local
        test1_${HINMOKU}@webmail.local
        test2_${HINMOKU}@webmail.local
        test3_${HINMOKU}@webmail.local
    )
    for mailaddr in "${MAIL_LIST[@]}"
    do
        echo "$mailaddr" | awk -F@ ' { print $1"@"$2"\t"$2"/"$1"/" } ' >> /etc/postfix/vmail_mailbox
        echo "$mailaddr:Y2fEjdGT1W6nsLqtJbGUVeUp9e4=" >> /etc/dovecot/passwd
    done
    postmap /etc/postfix/vmail_mailbox
    service postfix reload
    service dovecot restart
}

finish() {
    IP_ADDRESS=$(getIpAddress)
    echo "============================ DONE ============================"
    echo -e "*\tAdd below content to window host:"
    echo -e "*\t${IP_ADDRESS}\t ${WEB_DOMAIN}"
    echo "--------------------------------------------------------------"
    echo -e "*\tWeb Doamin:\t ${WEB_DOMAIN}"
    echo -e "*\tSource Dir:\t /WWW/${HINMOKU}"
    echo -e "*\tDB User:\t ${HINMOKU}/${HINMOKU}p"
    echo -e "*\tDB Name:\t ${HINMOKU}"
    echo "=============================================================="
}

HINMOKU=$1
SOURCE_URL=$2
if [ -z $HINMOKU ] 
then
    help
    exit
fi

WEB_DOMAIN="${HINMOKU}.local"

if [ $MG_MIGRATION_FLAG -eq "1" ]
then
    WEB_DOMAIN="${HINMOKU}.old.local"
fi

check
AVAILABLE=$?
if [ $AVAILABLE -eq "0" ]
then
    exit
fi

USERID=${HINMOKU: -5}

# Check user exists
USER_EXISTS="0"
if id "$HINMOKU" >/dev/null 2>&1; then
    USER_EXISTS="1"
    echo The user [${HINMOKU}] already exists, you want to continue \[y/n\] ?
    read CONTINUE_FLAG
fi

if [[ $CONTINUE_FLAG = "n" ]] || [[ $CONTINUE_FLAG = "N" ]]
then
    echo "User exit"
    exit
fi

# Create user if not exists
if [[ $USER_EXISTS = "0" ]]
then
    /usr/sbin/useradd -c '${HINMOKU}' -u ${USERID} -g customer -s /bin/bash -d /WWW/${HINMOKU} -m ${HINMOKU}
    chmod -R 705 /WWW/${HINMOKU}/
fi

# Change user pass
echo "Enter ${HINMOKU}p"
passwd ${HINMOKU}

# Add virtual host
cd ${VHOST_PATH}

sed -e 's/IPADDRESS/*/g' -e "s/USERNAME/${HINMOKU}/g" -e 's/GROUPNAME/customer/g' -e "s/SSLSERVERNAME/${WEB_DOMAIN}/g" -e "s/SERVERNAME/${WEB_DOMAIN}/g" -e "s/myserver:/*:/g" ${VHOST_TEMP_FILE} > ${HINMOKU}.conf

# Create log folder
mkdir -p ${APACHE_LOG_PATH}${HINMOKU}/http

mkdir -p ${APACHE_LOG_PATH}${HINMOKU}/https

# Checkout source code
cd /WWW

if [ ! -z $SOURCE_URL ] 
then
    if [[ -d /WWW/${HINMOKU}/.svn ]]
    then
        echo Folder [/WWW/${HINMOKU}] already exist, do you want to clear \[y/n\] ?
        read CLEAR_FLAG

        if [[ $CLEAR_FLAG = "y" ]] || [[ $CLEAR_FLAG = "Y" ]]
        then
            rm -rf /WWW/${HINMOKU}
            mkdir -p /WWW/${HINMOKU}
        fi
    fi
    svn checkout ${SOURCE_URL} ${HINMOKU}
fi

# Restart apache
service httpd restart

# Set permission for CGI folder
chown -R ${HINMOKU}:customer /WWW/${HINMOKU}/
chmod -R 705 /WWW/${HINMOKU}/
/usr/sbin/usermod -d /WWW/${HINMOKU} ${HINMOKU}

# Create database
createDatabase

finish
