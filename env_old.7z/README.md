<h1 style="text-align: center; text-transform: uppercase">Deploy Tool</h1>

## Overview
> Tool sử dụng để deploy web trên trên môi trường CentOS 6<br>
> Có thể config để deploy cho dự án MG migration hoặc dự án khác

## Working Flow

- Deploy source
- Create mail domain
- Create Mail list
	- default_[CNUMBER]@webmail.local
	- test1_[CNUMBER]@webmail.local
	- test2_[CNUMBER]@webmail.local
	- test3_[CNUMBER]@webmail.local
- Create database

## Step

1. Add `deploy_hinmoku.sh` to server

1. Config
> Set value của `MG_MIGRATION_FLAG` theo dự án muốn deploy như bên dưới:
	- `MG_MIGRATION_FLAG ="1"`:  Trường hợp chạy cho các dự án migration. Đang được setting default
	- `MG_MIGRATION_FLAG ="0"`: Trường hợp chạy cho các dự án khác

1. Execute command:
```sh
	./deploy_hinmoku.sh [CNUMBER] [SVN URL: Optional]
	Ex: deploy_hinmoku.sh c0022671 SVN
```

1. Add config to host
```sh
	[Server IP]	[CNUMBER].old.local [CNUMBER].old.webmail.local
	[Server IP]	[CNUMBER].local [CNUMBER].webmail.local
```