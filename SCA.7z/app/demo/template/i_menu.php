<nav class="navbar is-transparent">
    <div class="navbar-end">
        <a class="navbar-item" href="/sca_demo">
            Home
        </a>
        <a class="navbar-item" href="/sca_demo/add_message.php">
            Add message
        </a>
        <a class="navbar-item" href="/sca_demo/list_icon.php?pack=yellow">
            View available icons
        </a>
    </div>
</nav>