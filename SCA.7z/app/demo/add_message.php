<?php
global  $DBH;
include __DIR__ . '/include.php';
$user_id = 1;
if (isset($_POST['message'])) {
    $sql = sprintf("INSERT INTO messages(user_id, content) value(%d, '%s')", $user_id, $_POST['message']);
    $stm = $DBH->prepare($sql);
    if ($stm->execute()) {
        $add_message_success = true;
    } else {
        var_dump($DBH->errorInfo());
        die;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bulma.css">
    <title>Guest book</title>
</head>
<body>
<?php include 'template/i_menu.php'; ?>
<div class="container">
<?php if (isset($add_message_success) && $add_message_success): ?>
    <div class="notification is-primary">
        Add message successfully !
    </div>
<?php endif;?>
<form method="post">
    <div class="field">
        <label class="label">Message</label>
        <div class="control">
            <textarea name="message" class="textarea" placeholder=""></textarea>
        </div>
    </div>
    <div class="control">
        <button type="submit" class="button is-link">Submit</button>
    </div>
</form>
</div>
</body>
</html>