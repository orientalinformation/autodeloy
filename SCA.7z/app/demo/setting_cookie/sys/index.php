<?php
setcookie("bgcolor", 'red', time() + 3600, "/sca_demo/setting_cookie/", "localhost", false, 1);
?>
System site
<style>
    body{
        background: <?=$_COOKIE['bgcolor']?>;
    }
</style>