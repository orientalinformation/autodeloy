<?php
setcookie("allow_tracking", 1, time() + 3600, "/sca_demo/setting_cookie/", "localhost", false, 1);
setcookie("bgcolor", 'green', time() + 3600, "/sca_demo/setting_cookie/", "localhost", false, 1);
?>
Front site
<style>
    body{
        background: <?=$_COOKIE['bgcolor']?>;
    }
</style>