<?php
$command = 'dir ' . implode(DIRECTORY_SEPARATOR, [
       __DIR__,
       'img',
       'icons',
       $_GET['pack']
    ]);

$result  = shell_exec($command);
preg_match_all('/(\w+)\.png/', $result, $matches);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bulma.css">
    <title>Guest book</title>
</head>
<body>
<?php include 'template/i_menu.php'; ?>
<div class="container">
    <div class="table-container">
    <table class="table">
        <thead>
        <tr>
            <th>Icon</th>
            <th>Tag</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Icon</th>
            <th>Tag</th>
        </tr>
        </tfoot>
        <tbody>
        <?php foreach ($matches[1] as $icon_name): ?>
        <tr>
            <td>
                <img src="img\icons\<?=$_GET['pack']?>\<?=$icon_name?>.png" />
            </td>
            <td>[<?=$icon_name?>]</td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
</body>
</html>