
<?php
session_start();
global $DBH;
include __DIR__ . '/include.php';

checkAuth();

if(!empty($_GET['menu_id'])) {
    switch ($_GET['menu_id']) {
        case 's1':
            echo 'S1';
            break;
        case 's2':
            echo 'S2';
            break;
        case 's3':
            echo "S3";
            break;
        default:
            echo 'Error';
            break;
    }
    exit;
}

$has_permission = [
    's1' => checkUserPermission($_SESSION['user_info']['user_id'], 's1'),
    's2' => checkUserPermission($_SESSION['user_info']['user_id'], 's2'),
    's3' => checkUserPermission($_SESSION['user_info']['user_id'], 's3'),
];

$flash_message = getFlashMessage();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bulma.css">
    <title>Guest book - User permissions</title>
    <style>
        a {
            margin: 0 0 10px;
            display: block;
        }
    </style>
</head>
<body>
<?php include 'template/i_menu.php'; ?>
<div class="container">
    <?php if(!empty($flash_message)): ?>
        <div class="notification is-success">
            <button class="delete"></button>
            <?= $flash_message ?>
        </div>
    <?php endif; ?>
    <?php if($has_permission['s1']): ?>
    <a class="message is-link" href="user_permission.php?menu_id=s1">
        <div class="message-body">
            <p>s1</p>
        </div>
    </a>
    <?php endif; ?>
    <?php if($has_permission['s2']): ?>
    <a class="message is-link" href="user_permission.php?menu_id=s2">
        <div class="message-body">
            <p>s2</p>
        </div>
    </a>
    <?php endif; ?>
    <?php if($has_permission['s3']): ?>
    <a class="message is-link" href="user_permission.php?menu_id=s3">
        <div class="message-body">
            <p>s3</p>
        </div>
    </a>
    <?php endif; ?>
</div>
</body>
</html>