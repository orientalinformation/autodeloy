<?php
session_start(['cookie_path' => '/sca_demo/']);
include __DIR__ . '/include.php';

$errorMessage = '';
if (isset($_POST['login'])) {
    $_SESSION['username'] = $_POST['username'];
    $loginResult = login($_POST['username'], $_POST['password']);
    if (!empty($loginResult['user_id'])) {
        $_SESSION['user_info'] = $loginResult;
        $_SESSION['flash_message'] = 'Đăng nhập thành công !';
        header("Location: index.php");
    } else {
        $errorMessage = $loginResult;
    }
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bulma.css">
    <title>Guest book</title>
</head>
<body>
<div class="container">
    <?php if (!empty($errorMessage)): ?>
        <div class="notification is-danger">
            <button class="delete"></button>
            <?= $errorMessage ?>
        </div>
    <?php endif; ?>
    <form method="post">
        <div class="field">
            <label class="label">Username</label>
            <div class="control">
                <input class="input" name="username" type="text" placeholder="Username" value="<?= $_SESSION['username'] ?? '' ?>">
            </div>
        </div>

        <div class="field">
            <label class="label">Password</label>
            <div class="control">
                <input class="input" name="password" type="password" placeholder="Password" />
            </div>
        </div>

        <div class="field is-grouped">
            <div class="control">
                <input type="submit" name="login" value="Submit" class="button is-link"/>
            </div>
        </div>
    </form>
</div>
</body>
</html>