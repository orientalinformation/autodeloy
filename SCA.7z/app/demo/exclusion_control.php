<?php
session_start();
global $DBH;
include __DIR__ . '/include.php';

if (!empty($_POST['input'])) {
    //Update DB
    updateLuckyNumber($_POST['input']);
}

$lucky_number = getLuckyNumber();

sleep(3);

?>
<h1>
<?=htmlspecialchars($lucky_number)?>
</h1>
<form method="post">
    <input type="text" name="input">
    <input type="submit">
</form>
