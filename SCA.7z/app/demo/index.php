<?php
session_start();
global $DBH;
include __DIR__ . '/include.php';

$flash_message = getFlashMessage();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bulma.css">
    <title>Guest book</title>
    <style>
        .card {
            margin: 1.5em 0;
        }
    </style>
</head>
<body>
<?php include 'template/i_menu.php'; ?>
<div class="container">
    <?php if(!empty($flash_message)): ?>
    <div class="notification is-success">
        <button class="delete"></button>
        <?= $flash_message ?>
    </div>
    <?php endif; ?>
    <?php
    $sql = 'SELECT u.user_id, u.username, u.avatar, m.content, m.created_at from messages m join users u on u.user_id = m.user_id';
    ?>
    <?php foreach ($DBH->query($sql) as $row): ?>
    <div class="card">
        <div class="card-content">
            <div class="media">
                <div class="media-left">
                    <figure class="image is-48x48">
                        <img src="thumb.php?filename=<?=$row['avatar']?>" alt="Placeholder image">
                    </figure>
                </div>
                <div class="media-content">
                    <p class="title is-4"><?=$row['username']?></p>
                </div>
            </div>

            <div class="content">
                <?=$row['content']?>
                <br>
                <time datetime="2016-1-1"><?=$row['created_at']?></time>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
</body>
</html>