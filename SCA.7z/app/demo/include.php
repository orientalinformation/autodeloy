<?php
$dsn = 'mysql:dbname=guestbook;host=127.0.0.1';
$db_user = 'guestbook';
$db_password = 'guestbook';
$DBH = new PDO($dsn, $db_user, $db_password);
$USER_PERMISSIONS = null;

function getFlashMessage(){
    $message = $_SESSION['flash_message'] ?? '';
    unset($_SESSION['flash_message']);

    return $message;
}

function login($username, $password)
{
    if (empty($username) || empty($password)) {
        return 'Vui lòng nhập Username / Password';
    }
    /**
     * @var PDO
     */
    global $DBH;
    $encrypted_password = md5($password);
    $sql = "SELECT * FROM users WHERE username='$username' and password = '$encrypted_password'" ;
    $result = $DBH->query($sql)->fetch(PDO::FETCH_ASSOC);
    if (!$result) {
        return 'Username / Password khônng chính xác!';
    }

    return $result;
}

function checkAuth()
{
    if (empty($_SESSION['user_info'])) {
        header("Location: login.php");
        exit;
    }
}

function checkUserPermission($user_id, $menu_id)
{
    global $DBH;
    $sql = 'SELECT count(*) from users_permissions where user_id = :user_id and menu_id = :menu_id and auth_flag = 1';
    $stt = $DBH->prepare($sql);
    $stt->bindParam(':user_id', $user_id);
    $stt->bindParam(':menu_id', $menu_id);
    $stt->execute();

    return (int) $stt->fetch(PDO::FETCH_COLUMN);
}

function updateLuckyNumber($new_number)
{
    global $DBH;

    $setting_key = 'lucky_number';
    $updated_at = date('Y-m-d H:i:s.u');

    $sql = 'UPDATE settings SET setting_value = :new_number, updated_at = :updated_at, where setting_key = :setting_key';
    $stt = $DBH->prepare($sql);
    $stt->bindParam(':new_number', $new_number);
    $stt->bindParam(':setting_key', $setting_key);
    $stt->execute();
}

function getLuckyNumber()
{
    global $DBH;
    $sql = "SELECT setting_value from settings where setting_key='lucky_number'";

    $stt = $DBH->query($sql);

    $result = $stt->fetch(PDO::FETCH_ASSOC);

    return $result['setting_value'];
}
