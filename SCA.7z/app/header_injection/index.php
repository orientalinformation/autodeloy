<?php
//echo $_GET['url'];
$string = str_replace(array("\r", "\n"),  '', $_GET['url']);
echo $string;
//http://localhost:8089/index.php?url=http%3A%2F%2Fgoogle.com%0ALocation%3A%20http%3A%2F%2Fchungta.vn
header('Location: ' . $string);
